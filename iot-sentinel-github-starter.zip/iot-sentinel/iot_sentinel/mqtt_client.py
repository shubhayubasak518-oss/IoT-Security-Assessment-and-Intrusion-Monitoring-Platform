import time
import uuid
import paho.mqtt.client as mqtt
from .simulator import make_message

TOPIC = "iot-sentinel/telemetry"

def publish_messages(host="127.0.0.1", port=1883, count=10, topic=TOPIC):
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=f"iot-sentinel-pub-{uuid.uuid4().hex[:8]}")
    client.connect(host, port, keepalive=30)
    client.loop_start()
    try:
        for _ in range(count):
            info = client.publish(topic, make_message(), qos=0)
            info.wait_for_publish(timeout=3)
            time.sleep(0.2)
    finally:
        client.loop_stop()
        client.disconnect()

def listen(host="127.0.0.1", port=1883, topic=TOPIC):
    from .database import init_db, save_message, save_events
    from .detector import EventDetector
    from .validation import validate_payload

    init_db()
    detector = EventDetector()
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=f"iot-sentinel-sub-{uuid.uuid4().hex[:8]}")

    def on_connect(client, userdata, flags, reason_code, properties):
        if reason_code == 0:
            client.subscribe(topic)
            print(f"Listening on {topic}; press Ctrl+C to stop.")
        else:
            print(f"MQTT connection failed: {reason_code}")

    def on_message(client, userdata, msg):
        raw = msg.payload.decode("utf-8", errors="replace")
        valid, data, reason = validate_payload(raw)
        save_message(data, valid, reason)
        events = detector.inspect(valid, data, reason)
        save_events(events)
        if events:
            print("Security events:", events)

    client.on_connect = on_connect
    client.on_message = on_message
    client.connect(host, port, keepalive=30)
    try:
        client.loop_forever()
    except KeyboardInterrupt:
        print("Stopping subscriber...")
    finally:
        client.disconnect()
