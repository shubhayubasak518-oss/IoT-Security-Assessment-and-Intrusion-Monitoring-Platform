from pathlib import Path

def audit_mosquitto_config(config_path, require_tls=False):
    """Run lightweight static checks against a local Mosquitto-style config."""
    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"Configuration file not found: {path}")
    active_lines = [
        line.strip() for line in path.read_text(encoding="utf-8", errors="replace").splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    ]
    findings = []

    def add(rule_id, severity, title, evidence, remediation):
        findings.append({
            "rule_id": rule_id, "severity": severity, "title": title,
            "evidence": evidence, "remediation": remediation, "source": str(path),
        })

    if any(line.lower() == "allow_anonymous true" for line in active_lines):
        add("MQTT-001", "high", "Anonymous access enabled",
            "Found active directive: allow_anonymous true",
            "Disable anonymous access and configure authentication.")
    if not any(line.lower().startswith("acl_file ") for line in active_lines):
        add("MQTT-002", "medium", "No ACL file configured",
            "No active acl_file directive found in the supplied configuration.",
            "Configure topic-level access control appropriate to each device.")
    listeners = [line for line in active_lines if line.lower().startswith("listener ")]
    tls_configured = any(line.lower().startswith(("cafile ", "certfile ", "keyfile ")) for line in active_lines)
    if require_tls and listeners and not tls_configured:
        add("MQTT-003", "medium", "TLS settings not found",
            "Listener directive exists but no active CA/certificate/key setting was found.",
            "Configure TLS for listeners that require protected transport.")
    if not findings:
        add("AUDIT-000", "info", "No configured checks triggered",
            "No findings were detected by this lightweight static audit.",
            "Review the deployment and validate broker settings independently.")
    return findings
