import argparse
import csv
import json
from pathlib import Path
from .database import init_db, save_message, save_events, save_findings, fetch_all
from .detector import EventDetector
from .scanner import audit_mosquitto_config
from .simulator import demo_messages
from .validation import validate_payload

def run_demo(count=30):
    init_db()
    detector = EventDetector()
    for raw in demo_messages(count):
        valid, data, reason = validate_payload(raw)
        save_message(data, valid, reason)
        save_events(detector.inspect(valid, data, reason))
    print(f"Demo complete: processed {count} synthetic messages.")
    print("Launch dashboard with: streamlit run dashboard.py")

def run_audit(config_path, require_tls=False):
    findings = audit_mosquitto_config(config_path, require_tls=require_tls)
    init_db()
    save_findings(findings)
    print(json.dumps(findings, indent=2))
    return findings

def export_table(table, output_path, fmt):
    rows = fetch_all(table)
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    if fmt == "json":
        output.write_text(json.dumps(rows, indent=2), encoding="utf-8")
    else:
        with output.open("w", newline="", encoding="utf-8") as handle:
            if rows:
                writer = csv.DictWriter(handle, fieldnames=rows[0].keys())
                writer.writeheader()
                writer.writerows(rows)
    print(f"Exported {len(rows)} {table} records to {output}")

def main():
    parser = argparse.ArgumentParser(description="IoT Sentinel local demo and audit CLI")
    sub = parser.add_subparsers(dest="command", required=True)
    demo = sub.add_parser("demo", help="Generate synthetic telemetry and security events")
    demo.add_argument("--count", type=int, default=30)
    audit = sub.add_parser("audit", help="Audit a local Mosquitto-style configuration")
    audit.add_argument("--config", required=True)
    audit.add_argument("--require-tls", action="store_true")
    pub = sub.add_parser("publish", help="Publish simulated telemetry to a local MQTT broker")
    pub.add_argument("--host", default="127.0.0.1")
    pub.add_argument("--port", type=int, default=1883)
    pub.add_argument("--count", type=int, default=10)
    sub.add_parser("listen", help="Listen to local MQTT telemetry")
    sub.choices["listen"].add_argument("--host", default="127.0.0.1")
    sub.choices["listen"].add_argument("--port", type=int, default=1883)
    export = sub.add_parser("export", help="Export database records")
    export.add_argument("--table", choices=["messages", "events", "findings"], required=True)
    export.add_argument("--format", choices=["json", "csv"], default="json")
    export.add_argument("--output", required=True)
    args = parser.parse_args()

    if args.command == "demo":
        run_demo(max(0, args.count))
    elif args.command == "audit":
        run_audit(args.config, args.require_tls)
    elif args.command == "publish":
        from .mqtt_client import publish_messages
        publish_messages(args.host, args.port, args.count)
    elif args.command == "listen":
        from .mqtt_client import listen
        listen(args.host, args.port)
    elif args.command == "export":
        export_table(args.table, args.output, args.format)

if __name__ == "__main__":
    main()
