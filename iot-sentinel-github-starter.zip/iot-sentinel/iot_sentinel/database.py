import json
import sqlite3
from pathlib import Path
from datetime import datetime, timezone

DEFAULT_DB = Path("data/iot_sentinel.db")

def connect(db_path=DEFAULT_DB):
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    return conn

def init_db(db_path=DEFAULT_DB):
    with connect(db_path) as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT, received_at TEXT NOT NULL,
            device_id TEXT NOT NULL, message_id TEXT, device_type TEXT,
            telemetry_json TEXT, valid INTEGER NOT NULL, reason TEXT)""")
        conn.execute("""CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL,
            event_type TEXT NOT NULL, severity TEXT NOT NULL, device_id TEXT, details TEXT)""")
        conn.execute("""CREATE TABLE IF NOT EXISTS findings (
            id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL,
            rule_id TEXT NOT NULL, severity TEXT NOT NULL, title TEXT NOT NULL,
            evidence TEXT, remediation TEXT, source TEXT)""")

def save_message(data, valid, reason, db_path=DEFAULT_DB):
    data = data or {}
    with connect(db_path) as conn:
        conn.execute(
            """INSERT INTO messages(received_at, device_id, message_id, device_type,
               telemetry_json, valid, reason) VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (datetime.now(timezone.utc).isoformat(), data.get("device_id", "unknown"),
             data.get("message_id"), data.get("device_type"),
             json.dumps(data.get("telemetry", {})), int(valid), reason))

def save_events(events, db_path=DEFAULT_DB):
    if not events:
        return
    now = datetime.now(timezone.utc).isoformat()
    with connect(db_path) as conn:
        conn.executemany(
            """INSERT INTO events(created_at, event_type, severity, device_id, details)
               VALUES (?, ?, ?, ?, ?)""",
            [(now, e["event_type"], e["severity"], e.get("device_id"), e["details"]) for e in events])

def save_findings(findings, db_path=DEFAULT_DB):
    if not findings:
        return
    now = datetime.now(timezone.utc).isoformat()
    with connect(db_path) as conn:
        conn.executemany(
            """INSERT INTO findings(created_at, rule_id, severity, title, evidence, remediation, source)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            [(now, f["rule_id"], f["severity"], f["title"], f["evidence"],
              f["remediation"], f["source"]) for f in findings])

def fetch_all(table, db_path=DEFAULT_DB):
    if table not in {"messages", "events", "findings"}:
        raise ValueError("Unsupported table")
    with connect(db_path) as conn:
        return [dict(row) for row in conn.execute(f"SELECT * FROM {table} ORDER BY id DESC")]
