import json
import random
import time
import uuid

DEVICE_TYPES = {
    "sensor-001": "environment_sensor",
    "sensor-002": "environment_sensor",
    "lock-001": "smart_lock",
}

def make_message(device_id=None, anomaly=None):
    """Create synthetic telemetry. anomaly may be unknown, malformed, or replay."""
    device_id = device_id or random.choice(list(DEVICE_TYPES))
    actual_id = "unknown-device" if anomaly == "unknown" else device_id
    msg_id = "replayed-message-id" if anomaly == "replay" else str(uuid.uuid4())
    if actual_id == "lock-001":
        telemetry = {"locked": random.choice([True, False])}
    else:
        telemetry = {
            "temperature_c": round(random.uniform(19, 34), 2),
            "humidity_pct": round(random.uniform(25, 85), 2),
        }
    message = {
        "device_id": actual_id,
        "message_id": msg_id,
        "timestamp": time.time(),
        "device_type": DEVICE_TYPES.get(actual_id, "unknown"),
        "telemetry": telemetry,
    }
    if anomaly == "malformed":
        return '{"device_id":'
    return json.dumps(message)

def demo_messages(count=30):
    messages = []
    for i in range(count):
        if i == 8:
            messages.append(make_message(anomaly="unknown"))
        elif i == 15:
            messages.append(make_message(anomaly="malformed"))
        elif i in (22, 23):
            messages.append(make_message(anomaly="replay"))
        else:
            messages.append(make_message())
    return messages
