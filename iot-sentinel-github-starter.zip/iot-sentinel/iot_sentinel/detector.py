from collections import defaultdict, deque
import time

class EventDetector:
    """Explainable rules for a local IoT demo environment."""

    def __init__(self, known_devices=None, rate_limit=8, window_seconds=10):
        self.known_devices = set(known_devices or {"sensor-001", "sensor-002", "lock-001"})
        self.rate_limit = rate_limit
        self.window_seconds = window_seconds
        self.timestamps = defaultdict(deque)
        self.message_ids = set()

    def inspect(self, valid, data=None, reason="ok", received_at=None):
        received_at = time.time() if received_at is None else received_at
        events = []
        if not valid:
            events.append({
                "event_type": "malformed_payload",
                "severity": "medium",
                "device_id": (data or {}).get("device_id", "unknown"),
                "details": f"Payload rejected: {reason}",
            })
            return events

        device_id = data["device_id"]
        if device_id not in self.known_devices:
            events.append({
                "event_type": "unknown_device",
                "severity": "high",
                "device_id": device_id,
                "details": "Message received from a device not in the local allowlist.",
            })

        message_id = data["message_id"]
        if message_id in self.message_ids:
            events.append({
                "event_type": "possible_replay",
                "severity": "medium",
                "device_id": device_id,
                "details": "Previously observed message ID received again.",
            })
        self.message_ids.add(message_id)

        timestamps = self.timestamps[device_id]
        timestamps.append(received_at)
        while timestamps and received_at - timestamps[0] > self.window_seconds:
            timestamps.popleft()
        if len(timestamps) > self.rate_limit:
            events.append({
                "event_type": "message_rate_anomaly",
                "severity": "medium",
                "device_id": device_id,
                "details": f"{len(timestamps)} messages in {self.window_seconds} seconds; limit is {self.rate_limit}.",
            })
        return events
