import json

REQUIRED_FIELDS = {"device_id", "message_id", "timestamp", "device_type", "telemetry"}

def validate_payload(payload):
    """Validate JSON text or a decoded mapping; return (valid, data, reason)."""
    if isinstance(payload, str):
        try:
            data = json.loads(payload)
        except json.JSONDecodeError:
            return False, None, "invalid_json"
    elif isinstance(payload, dict):
        data = payload
    else:
        return False, None, "unsupported_payload_type"

    missing = REQUIRED_FIELDS - set(data.keys())
    if missing:
        return False, data, "missing_fields:" + ",".join(sorted(missing))
    if not isinstance(data["device_id"], str) or not data["device_id"].strip():
        return False, data, "invalid_device_id"
    if not isinstance(data["message_id"], str) or not data["message_id"].strip():
        return False, data, "invalid_message_id"
    if not isinstance(data["timestamp"], (int, float)):
        return False, data, "invalid_timestamp"
    if not isinstance(data["telemetry"], dict):
        return False, data, "invalid_telemetry"
    return True, data, "ok"
