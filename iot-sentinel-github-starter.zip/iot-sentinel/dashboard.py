import json
import pandas as pd
import streamlit as st
from iot_sentinel.database import init_db, fetch_all, save_findings
from iot_sentinel.scanner import audit_mosquitto_config

st.set_page_config(page_title="IoT Sentinel", page_icon="🛡️", layout="wide")
st.title("🛡️ IoT Sentinel")
st.caption("Local IoT security assessment and monitoring — synthetic lab data only.")

init_db()
messages = pd.DataFrame(fetch_all("messages"))
events = pd.DataFrame(fetch_all("events"))
findings = pd.DataFrame(fetch_all("findings"))

c1, c2, c3, c4 = st.columns(4)
c1.metric("Telemetry records", len(messages))
c2.metric("Security events", len(events))
c3.metric("Audit findings", len(findings))
c4.metric("Invalid messages", int((messages["valid"] == 0).sum()) if not messages.empty else 0)

st.subheader("Run a configuration audit")
config_path = st.selectbox("Choose local example configuration", [
    "config/example_insecure.conf", "config/example_hardened.conf"
])
require_tls = st.checkbox("Require TLS for listener configuration", value=False)
if st.button("Audit selected configuration"):
    try:
        new_findings = audit_mosquitto_config(config_path, require_tls=require_tls)
        save_findings(new_findings)
        st.success(f"Audit completed: {len(new_findings)} finding(s) recorded.")
        st.json(new_findings)
    except Exception as exc:
        st.error(f"Audit failed: {exc}")

left, right = st.columns(2)
with left:
    st.subheader("Security events")
    if events.empty:
        st.info("No events yet. Run `python -m iot_sentinel.cli demo` to generate synthetic data.")
    else:
        st.dataframe(events[["created_at", "event_type", "severity", "device_id", "details"]], use_container_width=True)
with right:
    st.subheader("Audit findings")
    if findings.empty:
        st.info("No findings stored yet. Run an audit above or use the CLI.")
    else:
        st.dataframe(findings[["created_at", "rule_id", "severity", "title", "remediation"]], use_container_width=True)

st.subheader("Telemetry")
if messages.empty:
    st.info("No telemetry records found.")
else:
    messages["telemetry"] = messages["telemetry_json"].apply(lambda value: json.loads(value) if value else {})
    st.dataframe(messages[["received_at", "device_id", "device_type", "valid", "reason"]], use_container_width=True)
    st.download_button(
        "Download events as CSV",
        data=events.to_csv(index=False).encode("utf-8") if not events.empty else b"",
        file_name="iot_sentinel_events.csv",
        mime="text/csv",
    )
