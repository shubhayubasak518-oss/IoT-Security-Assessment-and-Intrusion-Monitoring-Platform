import json
from iot_sentinel.validation import validate_payload

def valid_message():
    return {"device_id": "sensor-001", "message_id": "abc-123",
            "timestamp": 1700000000.0, "device_type": "environment_sensor",
            "telemetry": {"temperature_c": 25.2, "humidity_pct": 50.0}}

def test_valid_message():
    valid, data, reason = validate_payload(json.dumps(valid_message()))
    assert valid is True
    assert data["device_id"] == "sensor-001"
    assert reason == "ok"

def test_invalid_json():
    valid, data, reason = validate_payload("{bad")
    assert valid is False
    assert reason == "invalid_json"

def test_missing_field():
    message = valid_message()
    del message["telemetry"]
    valid, data, reason = validate_payload(message)
    assert valid is False
    assert reason.startswith("missing_fields")

def test_wrong_payload_type():
    valid, data, reason = validate_payload(123)
    assert valid is False
    assert reason == "unsupported_payload_type"
