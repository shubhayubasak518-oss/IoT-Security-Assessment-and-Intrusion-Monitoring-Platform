from iot_sentinel.detector import EventDetector

def message(device_id="sensor-001", message_id="id-1"):
    return {"device_id": device_id, "message_id": message_id,
            "timestamp": 1700000000, "device_type": "environment_sensor",
            "telemetry": {"temperature_c": 24}}

def test_unknown_device_detection():
    events = EventDetector().inspect(True, message("mystery-device"), received_at=1)
    assert any(event["event_type"] == "unknown_device" for event in events)

def test_repeated_message_id_detection():
    detector = EventDetector()
    detector.inspect(True, message(message_id="same"), received_at=1)
    events = detector.inspect(True, message(message_id="same"), received_at=2)
    assert any(event["event_type"] == "possible_replay" for event in events)

def test_malformed_payload_detection():
    events = EventDetector().inspect(False, None, "invalid_json", received_at=1)
    assert events[0]["event_type"] == "malformed_payload"

def test_rate_anomaly():
    detector = EventDetector(rate_limit=2, window_seconds=10)
    detector.inspect(True, message(message_id="1"), received_at=1)
    detector.inspect(True, message(message_id="2"), received_at=2)
    events = detector.inspect(True, message(message_id="3"), received_at=3)
    assert any(event["event_type"] == "message_rate_anomaly" for event in events)
