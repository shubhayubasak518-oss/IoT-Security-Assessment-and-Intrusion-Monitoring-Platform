from iot_sentinel.scanner import audit_mosquitto_config

def test_insecure_config_reports_anonymous_and_acl(tmp_path):
    config = tmp_path / "insecure.conf"
    config.write_text("listener 1883 127.0.0.1\nallow_anonymous true\n", encoding="utf-8")
    findings = audit_mosquitto_config(config, require_tls=True)
    rule_ids = {finding["rule_id"] for finding in findings}
    assert "MQTT-001" in rule_ids
    assert "MQTT-002" in rule_ids
    assert "MQTT-003" in rule_ids

def test_hardened_example_does_not_flag_known_patterns():
    findings = audit_mosquitto_config("config/example_hardened.conf", require_tls=True)
    rule_ids = {finding["rule_id"] for finding in findings}
    assert "MQTT-001" not in rule_ids
    assert "MQTT-002" not in rule_ids
    assert "MQTT-003" not in rule_ids

def test_missing_file_raises():
    try:
        audit_mosquitto_config("does-not-exist.conf")
    except FileNotFoundError:
        return
    raise AssertionError("Expected FileNotFoundError")
