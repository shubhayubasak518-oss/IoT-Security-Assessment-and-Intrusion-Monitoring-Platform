# IoT Sentinel — IoT Security Assessment & Monitoring

A software-only portfolio project that simulates IoT devices, validates telemetry, flags suspicious activity, audits example MQTT broker configuration, and displays findings in a Streamlit dashboard.

## Features
- Simulated temperature/humidity sensors and smart-lock telemetry
- MQTT publishing/subscribing using Eclipse Mosquitto and Paho MQTT
- Local demo mode that runs without a broker
- Security configuration checks for anonymous access, missing ACLs, and TLS settings
- Rule-based detection for unknown devices, malformed payloads, excessive message rates, and repeated message IDs
- SQLite persistence and JSON/CSV export
- Streamlit dashboard and Pytest unit tests

> Safety: Use this project only in your own local lab or on systems for which you have explicit authorization. This is a lightweight educational auditor, not a universal vulnerability scanner.

## Quick start (Windows)
1. Install Python 3.10+.
2. Extract the repository and open a terminal in this directory.
3. Create and activate a virtual environment:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```
4. Install dependencies:
   ```powershell
   pip install -r requirements.txt
   ```
5. Generate synthetic records:
   ```powershell
   python -m iot_sentinel.cli demo
   ```
6. Start the dashboard:
   ```powershell
   streamlit run dashboard.py
   ```
The dashboard reads from `data/iot_sentinel.db`. Run the demo command first to populate sample records.

## Audit the sample configurations
```powershell
python -m iot_sentinel.cli audit --config config/example_insecure.conf --require-tls
python -m iot_sentinel.cli audit --config config/example_hardened.conf --require-tls
```

## Run tests
```powershell
pytest -q
```

## Optional MQTT mode
Install [Eclipse Mosquitto](https://mosquitto.org/download/) and run a broker bound to loopback on your own machine. The provided `config/mosquitto_demo.conf` deliberately allows anonymous access for a local demonstration only; do not expose it to an untrusted network.

Terminal 1:
```powershell
python -m iot_sentinel.cli listen --host 127.0.0.1 --port 1883
```
Terminal 2:
```powershell
python -m iot_sentinel.cli publish --host 127.0.0.1 --port 1883 --count 20
```

## Architecture
```text
Virtual devices -> Telemetry validation -> Event detection -> SQLite
       |                                      |
       +---- MQTT broker (optional) ----------+
                                              +-> Streamlit dashboard
Local config files -> Security auditor --------> Findings / JSON / CSV reports
```

## Project layout
```text
iot-sentinel/
├── iot_sentinel/       # simulator, validation, scanner, detector, database, MQTT client, CLI
├── config/             # audit policy and sample broker/ACL configurations
├── tests/              # unit tests
├── data/               # local SQLite database (ignored by Git)
├── dashboard.py
├── requirements.txt
├── .gitignore
└── LICENSE
```

## Scope and limitations
The auditor checks a few explicit patterns in local Mosquitto-style configuration files: anonymous access, missing ACL configuration, and TLS settings when required. It does not prove a broker is secure and does not replace a full security review. Confirm findings against the actual deployment and broker documentation.

## Suggested demo
1. Run the demo command.
2. Open the dashboard and inspect devices and events.
3. Audit the insecure example, then the hardened example.
4. Run the test suite and publish the actual results in your portfolio.

## Future improvements
- Certificate-based device identity and authentication
- More robust broker configuration parsing
- Authenticated REST API
- ML anomaly detection after collecting and evaluating representative data
